<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<style>
body {
    background-color: #ffffff;
    font-family: "Poppins", sans-serif;
}

/* Card */
.card {
    border-radius: 18px;
    border: 1px solid #ffd6ea;
    background-color: #ffffff;
    box-shadow: 0 4px 12px rgba(255, 182, 217, 0.25);
}

/* Button */
.btn-primary {
    background-color: #ff8ec7;
    border-color: #ff8ec7;
}
.btn-primary:hover {
    background-color: #ff6fb6;
    border-color: #ff6fb6;
}

/* Title */
h3 {
    color: #b7005c;
    font-weight: bold;
}
</style>

<div class="container mt-5">
    <div class="col-md-4 mx-auto card p-4">

        <h3 class="text-center mb-3">Login</h3>

        @if (session('error'))
            <div class="alert alert-danger">{{ session('error') }}</div>
        @endif

        <form action="{{ route('login.process') }}" method="POST">
            @csrf

            <div class="mb-3">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>

            <div class="mb-3">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>

            <button class="btn btn-primary w-100">Login</button>

            <p class="mt-3 text-center">
                Belum punya akun? <a href="{{ route('register') }}">Register</a>
            </p>
        </form>
    </div>
</div>

</body>
</html>
