{{-- Panggil layout utama yang sudah dibuat (misalnya layout.blade.php) --}}
@extends('layout')

{{-- Isi title halaman ini --}}
@section('title', 'Hotel Mewah - Selamat Datang')

{{-- ================================================================= --}}
{{-- START OF MAIN CONTENT --}}
{{-- ================================================================= --}}
@section('content')

    {{-- HERO SECTION - Banner Utama --}}
    <div style="text-align: center; padding: 100px 0; background-color: #000;">
        <div style="max-width: 900px; margin: auto;">
            <h1 style="font-size: 3.8em; color: var(--color-primary); margin-bottom: 20px; text-transform: uppercase;">
                Pengalaman Menginap Eksklusif
            </h1>
            <p style="font-size: 1.3em; color: white; margin-bottom: 40px; font-weight: 300;">
                Nikmati kemewahan dan pelayanan personal bintang lima di jantung kota.
            </p>
            <a href="/reservasi" class="btn-gold" style="font-size: 1.2em; padding: 15px 40px;">
                Cek Ketersediaan Kamar
            </a>
        </div>
    </div>
    
    <hr style="border: none; border-top: 1px solid var(--color-primary); margin: 0;">

    {{-- SECTION: KATEGORI KAMAR --}}
    <div style="padding: 60px 20px; text-align: center; background-color: var(--color-secondary);">
        <h2 style="color: white; margin-bottom: 50px; border-bottom: 2px solid var(--color-primary); display: inline-block; padding-bottom: 5px;">
            Kamar Pilihan Kami
        </h2>
        
        {{-- Container untuk 3 Card Kamar --}}
        <div style="display: flex; justify-content: center; flex-wrap: wrap; gap: 30px;">
            
            @php
                $rooms = [
                    ['name' => 'DELUXE SUITE', 'price' => 'Rp 950.000', 'desc' => 'Kenyamanan maksimal dengan pemandangan kota yang menakjubkan.'],
                    ['name' => 'EXECUTIVE ROOM', 'price' => 'Rp 1.500.000', 'desc' => 'Ruang kerja dan istirahat premium, ideal untuk pebisnis.'],
                    ['name' => 'ROYAL PENTHOUSE', 'price' => 'Rp 4.000.000', 'desc' => 'Kemewahan tanpa batas dengan fasilitas dan layanan personal.'],
                ];
            @endphp

            @foreach ($rooms as $room)
                <div style="width: 300px; padding: 25px; background-color: #1a1a1a; border: 1px solid var(--color-primary); border-radius: 8px; text-align: left; transition: transform 0.3s; box-shadow: 0 4px 8px rgba(0,0,0,0.5);">
                    <h3 style="color: var(--color-primary); margin-top: 0;">{{ $room['name'] }}</h3>
                    <p style="color: #bbb; font-size: 0.9em;">{{ $room['desc'] }}</p>
                    <p style="color: white; font-weight: bold; font-size: 1.2em; margin-bottom: 15px;">Mulai dari {{ $room['price'] }}</p>
                    <a href="/rooms/{{ strtolower(str_replace(' ', '-', $room['name'])) }}" class="btn-gold" style="padding: 8px 15px; font-size: 0.9em;">
                        Lihat Detail
                    </a>
                </div>
            @endforeach
            
        </div>
    </div>
    
    <hr style="border: none; border-top: 1px solid var(--color-primary); margin: 0;">

    {{-- SECTION: CTA Akhir --}}
    <div style="padding: 40px 20px; text-align: center; background-color: #000;">
        <h3 style="color: white;">Reservasi Anda, Prioritas Kami</h3>
        <p style="color: var(--color-primary); margin-bottom: 25px;">Pesan sekarang untuk mendapatkan penawaran spesial eksklusif.</p>
        <a href="/reservasi" class="btn-gold" style="font-size: 1.2em; padding: 15px 50px;">
            PESAN SEKARANG
        </a>
    </div>

@endsection
