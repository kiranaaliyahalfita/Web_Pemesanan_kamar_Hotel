@extends('layout')

@section('content')
<div class="container mt-4">

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Email</th>
                <th>No. HP</th>
                <th>Alamat</th>
                <th width="150px">Aksi</th>
            </tr>
        </thead>

        <tbody>
            @php $no = 1; @endphp
            
            @foreach ($penggunas as $item) 
            <tr>
                <td>{{ $no++ }}</td>
                <td>{{ $item->nama }}</td>
                <td>{{ $item->email }}</td>
                <td>{{ $item->nomor_handphone }}</td>
                <td>{{ $item->alamat }}</td>
                
                <td>
                    <a href="{{ route('pengguna.edit', $item->id) }}" class="btn btn-warning btn-sm">Edit</a>

                    <form action="{{ route('pengguna.destroy', $item->id) }}"
                          method="POST" style="display:inline-block;">
                        @csrf
                        @method('DELETE')

                        <button type="submit" class="btn btn-danger btn-sm"
                                onclick="return confirm('Hapus data ini?')">
                            Delete
                        </button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection