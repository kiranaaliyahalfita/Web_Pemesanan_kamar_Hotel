@extends('layouts.app')

@section('content')
<div class="container">

    <h3>Edit Reservasi</h3>

    <form action="{{ route('reservation.update', $reservation->id) }}" method="POST">
        @csrf
        @method('PUT')

        <label>Nama Pengguna</label>
        <input type="text" name="nama_pengguna" class="form-control"
            value="{{ $reservation->nama_pengguna }}" required>

        <label>Tipe Kamar</label>
        <select name="tipe_kamar" id="tipe_kamar" class="form-control" required>
            <option value="VVIP" {{ $reservation->tipe_kamar == 'VVIP' ? 'selected' : '' }}>VVIP</option>
            <option value="VIP" {{ $reservation->tipe_kamar == 'VIP' ? 'selected' : '' }}>VIP</option>
            <option value="CLASIC" {{ $reservation->tipe_kamar == 'CLASIC' ? 'selected' : '' }}>CLASIC</option>
        </select>

        <label>Tanggal Check In</label>
        <input type="date" name="tanggal_check_in" class="form-control"
            value="{{ $reservation->tanggal_check_in }}" required>

        <label>Tanggal Check Out</label>
        <input type="date" name="tanggal_check_out" class="form-control"
            value="{{ $reservation->tanggal_check_out }}" required>

        <label>Status</label>
        <select name="status" class="form-control" required>
            <option value="Pending" {{ $reservation->status == 'Pending' ? 'selected' : '' }}>Pending</option>
            <option value="Sukses" {{ $reservation->status == 'Sukses' ? 'selected' : '' }}>Sukses</option>
        </select>

        <label>Total Harga</label>
        <input type="text" id="total_harga" name="total_harga" class="form-control"
            value="{{ $reservation->total_harga }}" readonly>

        <br>
        <button class="btn btn-primary">Update</button>
    </form>
</div>

<script>
    function setHarga() {
        let tipe = document.getElementById("tipe_kamar").value;
        let harga = 0;

        if (tipe === "VVIP") harga = 500000;
        if (tipe === "VIP") harga = 300000;
        if (tipe === "CLASIC") harga = 150000;

        document.getElementById("total_harga").value = harga;
    }

    
    document.getElementById("tipe_kamar").addEventListener("change", setHarga);

    
    window.onload = setHarga;
</script>

@endsection
