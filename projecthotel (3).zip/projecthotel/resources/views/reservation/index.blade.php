@extends('layout')

@section('content')

<div class="container mt-4">

    <h2>Data Reservation</h2>

    {{-- Tombol Tambah --}}
    <a href="{{ route('reservation.create') }}" class="btn btn-success mb-3">
        + Tambah Reservation
    </a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Nama Pengguna</th>
                <th>Tipe Kamar</th>
                <th>Check In</th>
                <th>Check Out</th>
                <th width="150px">Aksi</th>
            </tr>
        </thead>

        <tbody>
            @foreach ($reservations as $item)
            <tr>
                <td>{{ $item->nama_pengguna }}</td>
                <td>{{ $item->tipe_kamar }}</td>
                <td>{{ $item->tanggal_check_in }}</td>
                <td>{{ $item->tanggal_check_out }}</td>

                <td>
                    {{-- PERBAIKAN AKHIR UNTUK URLGENERATIONEXCEPTION --}}
                    {{-- Menggunakan array eksplisit untuk parameter 'reservation' --}}
                    <a href="{{ route('reservation.edit', ['reservation' => $item->reservation_id]) }}"
                       class="btn btn-warning btn-sm">
                        Edit
                    </a>

                    {{-- Menggunakan array eksplisit untuk destroy --}}
                    <form action="{{ route('reservation.destroy', ['reservation' => $item->reservation_id]) }}"
                          method="POST" style="display:inline-block;">
                        @csrf
                        @method('DELETE')

                        <button class="btn btn-danger btn-sm"
                                onclick="return confirm('Hapus data ini?')">
                            Delete
                        </button>
                    </form>

                </td>
            </tr>
            @endforeach
        </tbody>
    </table>

</div>

@endsection 