@extends('layouts.app')

@section('content')
<style>
    /* Gold Estetik Styling for the Form */

    /* Container untuk header dan form */
    .container {
        padding-top: 20px;
    }
    
    /* Judul utama (Emas Tua) */
    h2 {
        color: #b8860b; /* Warna Gold */
        font-weight: 700;
        border-bottom: 2px solid #e0c896; /* Garis bawah emas lembut */
        padding-bottom: 5px;
        margin-bottom: 20px;
    }

    /* Form Card */
    form {
        border-radius: 15px;
        background: white;
        padding: 30px;
        /* Bayangan emas lembut */
        box-shadow: 0 4px 15px rgba(184, 134, 11, 0.15);
        border: 1px solid #e0c896; /* Garis tepi emas lembut */
    }

    /* Label Input (Cokelat Emas Tua) */
    label {
        font-weight: 600;
        color: #8b6b3e; /* Cokelat Emas Tua */
        margin-bottom: 5px;
    }

    /* Input Field dan Select (Gaya yang bersih) */
    .form-control {
        border-radius: 8px;
        border: 1px solid #ccc;
        transition: border-color 0.3s;
    }

    /* Fokus pada Input (Warna Emas saat diklik) */
    .form-control:focus {
        border-color: #b8860b; /* Warna Gold saat fokus */
        box-shadow: 0 0 0 0.25rem rgba(184, 134, 11, 0.25); /* Glow emas */
    }

    /* Tombol Utama (Bayar - Gold) */
    .btn-primary {
        background-color: #b8860b; /* Warna Gold */
        border-color: #b8860b;
        color: white;
        border-radius: 10px;
        font-weight: 600;
        transition: background-color 0.3s;
        margin-top: 15px;
    }

    .btn-primary:hover {
        background-color: #daa520; /* Warna Goldenrod */
        border-color: #daa520;
    }
    
    /* Tombol Sekunder (Kembali - Cokelat Emas) */
    .btn-secondary {
        background-color: #8b6b3e; /* Cokelat Emas Tua */
        border-color: #8b6b3e;
        color: white;
        border-radius: 10px;
        font-weight: 600;
        transition: background-color 0.3s;
        margin-top: 15px;
    }

    .btn-secondary:hover {
        background-color: #a0835f; 
        border-color: #a0835f;
    }
</style>

<div class="container">
    <h2>Pembayaran Reservasi</h2>

    {{-- Penyesuaian action URL --}}
    <form action="{{ route('pembayaran.store') }}" method="POST">
        @csrf

        <div class="mb-3">
            <label for="reservation_id">Pilih Reservasi</label>
            {{-- Nama input disesuaikan menjadi 'reservation_id' --}}
            <select name="reservation_id" id="reservation_id" class="form-control" required>
                <option value="">-- Pilih Reservasi --</option>

                @foreach ($reservations as $r)
                    <option value="{{ $r->reservation_id }}"
                        data-harga="{{ $r->total_harga }}">
                        {{ $r->nama_pengguna }} - {{ $r->tipe_kamar }} ({{ $r->tanggal_check_in }}) - Total: {{ number_format($r->total_harga, 0, ',', '.') }}
                    </option>
                @endforeach

            </select>
        </div>

        <div class="mb-3">
            <label for="jumlah_bayar">Jumlah Pembayaran</label>
            {{-- Nama input disesuaikan menjadi 'jumlah_bayar' --}}
            <input type="number" name="jumlah_bayar" id="jumlah_bayar" class="form-control" readonly required>
        </div>

        {{-- Field tanggal_bayar ditambahkan --}}
        <div class="mb-3">
            <label for="tanggal_bayar">Tanggal Pembayaran</label>
            <input type="date" name="tanggal_bayar" id="tanggal_bayar" class="form-control" value="{{ date('Y-m-d') }}" required>
        </div>

        <div class="mb-3">
            <label for="metode">Metode Pembayaran</label>
            {{-- Nama input disesuaikan menjadi 'metode' --}}
            <select name="metode" id="metode" class="form-control" required>
                <option value="">-- Pilih Metode --</option>
                <option value="Transfer">Transfer Bank</option>
                <option value="E-Wallet">E-Wallet</option>
                <option value="Tunai">Tunai</option>
                <option value="Kartu">Kartu Debit/Kredit</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Bayar</button>
        <a href="{{ route('pembayaran.index') }}" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const selectReservasi = document.getElementById('reservation_id');
    const jumlahInput = document.getElementById('jumlah_bayar');

    selectReservasi.addEventListener('change', function () {
        const selectedOption = this.options[this.selectedIndex];
        // Pastikan opsi yang dipilih valid (bukan opsi "-- Pilih Reservasi --")
        if (selectedOption.value) {
            const harga = selectedOption.getAttribute('data-harga');
            // Isi input jumlah_bayar dengan total harga dari data reservasi
            jumlahInput.value = harga;
        } else {
            // Jika opsi default dipilih, kosongkan input
            jumlahInput.value = '';
        }
    });
});
</script>
@endsection