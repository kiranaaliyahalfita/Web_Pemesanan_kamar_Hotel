@extends('layouts.app')

@section('content')
<div class="container">
    <h3>Data Pembayaran</h3>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Pengguna</th>
                <th>Jumlah</th>
                <th>Metode</th>
                <th>Tanggal</th>
            </tr>
        </thead>

        <tbody>
            @foreach($pembayaran as $pay)
            <tr>
                <td>{{ $pay->id_pembayaran }}</td>
                <td>{{ $pay->reservation->nama_pengguna }}</td>
                <td>Rp {{ number_format($pay->jumlah,0,',','.') }}</td>
                <td>{{ $pay->metode_pembayaran }}</td>
                <td>{{ $pay->tanggal_pembayaran }}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
