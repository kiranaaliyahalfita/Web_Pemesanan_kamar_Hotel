<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Form Pembayaran</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #fff8e1; /* Gold soft */
            margin: 0;
            padding: 0;
        }

        .container {
            width: 45%;
            margin: 40px auto;
            background: white;
            padding: 25px;
            border-radius: 12px;
            border: 2px solid #d4af37; /* gold border */
            box-shadow: 0 0 15px rgba(212, 175, 55, 0.5);
        }

        h2 {
            text-align: center;
            color: #b8860b;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            color: #6e5100;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            margin-bottom: 15px;
            border-radius: 8px;
            border: 1px solid #bfa25d;
            background: #fffdf5;
        }

        input:focus, select:focus {
            border-color: #d4af37;
            outline: none;
            box-shadow: 0 0 5px rgba(212, 175, 55, 0.6);
        }

        button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(90deg, #d4af37, #b8860b);
            border: none;
            color: white;
            font-size: 16px;
            border-radius: 10px;
            cursor: pointer;
            font-weight: bold;
        }

        button:hover {
            background: linear-gradient(90deg, #b8860b, #d4af37);
        }

        .back-btn {
            margin-top: 15px;
            display: block;
            text-align: center;
            text-decoration: none;
            color: #6e5100;
            font-weight: bold;
        }

        select option {
            background: white;
        }
    </style>
</head>
<body>

    <div class="container">

        <h2>Form Pembayaran</h2>

        @if(session('success'))
            <div style="color: green; font-weight: bold; margin-bottom: 15px;">
                {{ session('success') }}
            </div>
        @endif

        <form action="{{ route('pembayaran.store') }}" method="POST">
            @csrf

            <label for="nama_pengguna">Nama Pengguna</label>
            <input type="text" name="nama_pengguna" required>

            <label for="tipe_kamar">Tipe Kamar</label>
            <select name="tipe_kamar" required id="tipe_kamar" onchange="updateHarga()">
                <option value="">-- Pilih Tipe Kamar --</option>
                <option value="VVIP">VVIP</option>
                <option value="VIP">VIP</option>
                <option value="CLASIC">CLASIC</option>
            </select>

            <label for="harga">Harga (Otomatis)</label>
            <input type="number" name="harga" id="harga" readonly required>

            <label for="metode">Metode Pembayaran</label>
            <select name="metode" required>
                <option value="">-- Pilih Metode --</option>
                <option value="CASH">CASH</option>
                <option value="TRANSFER">TRANSFER</option>
            </select>

            <button type="submit">Simpan Pembayaran</button>
        </form>

        <a href="{{ route('pembayaran.index') }}" class="back-btn">← Kembali</a>

    </div>

    <script>
        function updateHarga() {
            const tipe = document.getElementById("tipe_kamar").value;
            const hargaInput = document.getElementById("harga");

            let harga = 0;

            if (tipe === "VVIP") harga = 1500000;
            if (tipe === "VIP") harga = 900000;
            if (tipe === "CLASIC") harga = 500000;

            hargaInput.value = harga;
        }
    </script>

</body>
</html>
