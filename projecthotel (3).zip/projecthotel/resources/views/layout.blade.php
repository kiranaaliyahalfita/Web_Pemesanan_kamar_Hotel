<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplikasi Reservasi</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        /* ==================================== */
        /* GOLD ESTETIK: TEMA GLOBAL UNTUK LAYOUT */
        /* ==================================== */
        
        /* 1. Latar Belakang Body */
        body {
            background-color: #fcf8e3; /* Krem lembut (Ivory) */
            font-family: "Poppins", sans-serif;
        }

        /* 2. Navbar (Menggantikan bg-dark) */
        .navbar {
            background-color: #e0c896 !important; /* Emas lembut */
            box-shadow: 0 2px 8px rgba(184, 134, 11, 0.3); /* Bayangan emas */
            border-bottom: 3px solid #b8860b; /* Garis bawah emas tua */
            margin-bottom: 25px;
        }

        /* 3. Teks di Navbar (Brand dan Link) */
        .navbar-brand, 
        .navbar-nav .nav-link, 
        .navbar-toggler-icon {
            font-weight: bold;
            color: #8b6b3e !important; /* Cokelat Emas Tua */
        }
        
        /* Hover link di navbar */
        .navbar-nav .nav-link:hover {
            color: #b8860b !important; /* Gold */
        }

        /* 4. Judul Halaman (H1/H2) */
        h1, h2 {
            color: #b8860b; /* Warna Gold */
            font-weight: 700;
            border-bottom: 2px solid #e0c896;
            padding-bottom: 5px;
            margin-bottom: 15px;
        }
        
        /* 5. Styling Tabel (Diterapkan ke semua table-bordered) */
        .table-bordered {
            border: 1px solid #e0c896; 
            border-radius: 10px;
            overflow: hidden; 
            box-shadow: 0 4px 15px rgba(184, 134, 11, 0.1); 
            background-color: white;
        }
        .table-bordered thead tr {
            background-color: #e0c896; 
        }
        .table-bordered thead th {
            color: #8b6b3e; 
            border-bottom: 2px solid #b8860b;
            font-weight: 700;
        }
        .table-bordered tbody tr:nth-child(even) {
            background-color: #fcf8e3; 
        }

        /* 6. Styling Tombol (btn-success, btn-primary, btn-warning, btn-danger) */
        .btn-success, .btn-primary { /* Tombol Tambah/Simpan */
            background-color: #b8860b; 
            border-color: #b8860b;
            color: white;
            font-weight: 600;
            border-radius: 8px;
            transition: background-color 0.3s;
        }
        .btn-success:hover, .btn-primary:hover {
            background-color: #daa520; 
            border-color: #daa520;
        }
        .btn-warning { /* Tombol Edit */
            background-color: #daa520; 
            border-color: #daa520;
            color: white;
            border-radius: 6px;
        }
        .btn-warning:hover {
            background-color: #b8860b; 
            border-color: #b8860b;
        }
        .btn-danger { /* Tombol Delete/Logout */
            background-color: #a52a2a; 
            border-color: #a52a2a;
            border-radius: 6px;
        }
        .btn-danger:hover {
            background-color: #800000; 
            border-color: #800000;
        }

    </style>
</head>

<body>

    {{-- MENGHAPUS KELAS navbar-dark dan bg-dark --}}
    <nav class="navbar navbar-expand-lg">
        <div class="container">

            <a class="navbar-brand" href="{{ route('home') }}">
                HOTEL APP
            </a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" 
                    data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" 
                    aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">

                <ul class="navbar-nav me-auto">

                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('reservation.index') }}">
                            Reservasi
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('pembayaran.index') }}">
                            Pembayaran
                        </a>
                    </li>
                    
                    {{-- Tambahkan link untuk Pengguna di sini jika perlu --}}
                    {{-- <li class="nav-item">
                        <a class="nav-link" href="{{ route('pengguna.index') }}">
                            Pengguna
                        </a>
                    </li> --}}

                </ul>

                <form action="{{ route('logout') }}" method="POST">
                    @csrf
                    {{-- Menggunakan btn-danger yang sudah di-style Gold --}}
                    <button class="btn btn-danger btn-sm">Logout</button>
                </form>

            </div>

        </div>
    </nav>

    <div class="container">
        @yield('content')
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>