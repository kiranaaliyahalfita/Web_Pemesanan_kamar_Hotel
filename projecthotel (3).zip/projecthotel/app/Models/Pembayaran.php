<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pembayaran extends Model
{
    protected $table = 'pembayaran';

    protected $primaryKey = 'id_pembayaran';
    public $timestamps = false;

    protected $fillable = [
        'jumlah',
        'metode_pembayaran',
        'tanggal_pembayaran',
        'reservation_id',
    ];

    public function reservation()
    {
        return $this->belongsTo(Reservation::class, 'reservation_id');
    }
}
