<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Reservation extends Model
{
    protected $table = 'reservation';
    protected $primaryKey = 'id';
    public $timestamps = false;

    protected $fillable = [
        'nama_pengguna',
        'tipe_kamar',
        'tanggal_check_in',
        'tanggal_check_out',
        'tanggal_booking',
        'status',
        'total_harga',
    ];
}
