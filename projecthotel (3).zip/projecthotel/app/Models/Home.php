<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Hotel</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        /* Mengubah latar belakang menjadi warna krem lembut */
        body {
            background-color: #fcf8e3; /* Warna krem/off-white yang cocok dengan emas */
            font-family: "Poppins", sans-serif;
        }

        /* Mengubah kartu agar lebih elegan */
        .card {
            border-radius: 18px;
            /* Memberi bayangan emas lembut */
            box-shadow: 0 4px 12px rgba(184, 134, 11, 0.25);
            border: 1px solid #e0c896; /* Garis tepi emas/krem */
            background-color: #ffffff; /* Latar belakang kartu tetap putih */
        }

        /* Mengubah warna teks selamat datang menjadi emas tua */
        .welcome {
            font-weight: 700;
            color: #8b6b3e; /* Warna cokelat-emas tua */
        }

        /* Teks teredam (muted) juga disesuaikan */
        .text-muted {
            color: #a0a0a0 !important;
        }
        
        /* Gaya utama tombol (emas) */
        .btn-main {
            background-color: #b8860b; /* Warna Gold */
            color: white; /* Teks putih */
            border-radius: 10px;
            border: none;
            transition: background-color 0.3s ease;
        }

        .btn-main:hover {
            background-color: #daa520; /* Warna Goldenrod, sedikit lebih terang saat di-hover */
            color: white;
        }
        
        /* Tombol Logout (merah) mungkin perlu disesuaikan agar tetap terlihat */
        .btn-danger {
            background-color: #a52a2a; /* Cokelat kemerahan */
            border: none;
        }

        .btn-danger:hover {
            background-color: #800000; /* Merah marun */
        }
    </style>
</head>
<body>

<div class="container mt-5">

    <div class="text-center mb-4">
        <h2 class="welcome">Selamat Datang, {{ Auth::user()->name }} 👋</h2>
        <p class="text-muted">Anda berhasil login ke aplikasi hotel.</p>
    </div>

    <div class="row justify-content-center">

        <div class="col-md-6">
            <div class="card p-4">
                <h4 class="mb-3 text-center welcome">Menu Utama</h4>

                <a href="{{ route('pengguna.index') }}" class="btn btn-main w-100 mb-2">
                    Kelola Pengguna
                </a>

                <a href="{{ route('reservation.index') }}" class="btn btn-main w-100 mb-2">
                    Kelola Reservasi
                </a>

                <a href="{{ route('pembayaran.index') }}" class="btn btn-main w-100 mb-2">
                    Kelola Pembayaran
                </a>

                <form action="{{ route('logout') }}" method="POST" class="mt-3">
                    @csrf
                    <button class="btn btn-danger w-100">Logout</button>
                </form>
            </div>
        </div>

    </div>

</div>

</body>
</html>