<?php

namespace App\Http\Controllers;

use App\Models\Pengguna;
use Illuminate\Http\Request;

class PenggunaController extends Controller
{
    public function index()
    {
        
        $penggunas = Pengguna::all();
        
       
        return view('pengguna.index', compact('penggunas'));
    }

    public function create()
    {
        return view('pengguna.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama' => 'required',
            'email' => 'required|email',
            'nomor_handphone' => 'required',
            'alamat' => 'required',
        ]);

        Pengguna::create($request->all());

        return redirect()->route('pengguna.index')->with('success', 'Data pengguna berhasil ditambahkan.');
    }

    public function edit($id)
    {
        // Variabel diubah dari $data menjadi $pengguna (tunggal)
        $pengguna = Pengguna::findOrFail($id);
        
        // Mengirimkan $pengguna ke view
        return view('pengguna.edit', compact('pengguna'));
    }

    public function update(Request $request, $id)
    {
        // Menggunakan $pengguna
        $pengguna = Pengguna::findOrFail($id);
        $pengguna->update($request->all());

        return redirect()->route('pengguna.index')->with('success', 'Data pengguna berhasil diperbarui.');
    }

    public function destroy($id)
    {
        Pengguna::destroy($id);
        return redirect()->route('pengguna.index')->with('success', 'Data pengguna berhasil dihapus.');
    }
}