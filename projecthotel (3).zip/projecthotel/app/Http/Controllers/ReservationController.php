<?php

namespace App\Http\Controllers;

use App\Models\Reservation;
use Illuminate\Http\Request;

class ReservationController extends Controller
{
    public function index()
    {
        $reservations = Reservation::all();
        return view('reservation.index', compact('reservations'));
    }

    public function create()
    {
        return view('reservation.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama_pengguna' => 'required',
            'tipe_kamar' => 'required',
            'tanggal_check_in' => 'required',
            'tanggal_check_out' => 'required',
            'status' => 'required',
            'total_harga' => 'required'
        ]);

        Reservation::create([
            'nama_pengguna' => $request->nama_pengguna,
            'tipe_kamar' => $request->tipe_kamar,
            'tanggal_check_in' => $request->tanggal_check_in,
            'tanggal_check_out' => $request->tanggal_check_out,
            'tanggal_booking' => now(),
            'status' => $request->status,
            'total_harga' => $request->total_harga,
        ]);

        return redirect()->route('reservation.index')->with('success', 'Berhasil disimpan!');
    }

    public function edit($id)
    {
        $reservation = Reservation::findOrFail($id);
        return view('reservation.edit', compact('reservation'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'nama_pengguna' => 'required',
            'tipe_kamar' => 'required',
            'tanggal_check_in' => 'required',
            'tanggal_check_out' => 'required',
            'status' => 'required',
            'total_harga' => 'required'
        ]);

        $reservation = Reservation::findOrFail($id);

        $reservation->update([
            'nama_pengguna' => $request->nama_pengguna,
            'tipe_kamar' => $request->tipe_kamar,
            'tanggal_check_in' => $request->tanggal_check_in,
            'tanggal_check_out' => $request->tanggal_check_out,
            'status' => $request->status,
            'total_harga' => $request->total_harga,
        ]);

        return redirect()->route('reservation.index')->with('success', 'Data berhasil diperbarui!');
    }

    public function destroy($id)
    {
        $reservation = Reservation::findOrFail($id);
        $reservation->delete();

        return redirect()->route('reservation.index')->with('success', 'Data berhasil dihapus!');
    }
}
