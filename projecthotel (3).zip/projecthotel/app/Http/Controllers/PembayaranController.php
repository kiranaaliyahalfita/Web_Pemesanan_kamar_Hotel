<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Reservation;
use App\Models\Pembayaran;

class PembayaranController extends Controller
{
    // =======================
    // LIST PEMBAYARAN
    // =======================
    public function index()
    {
        $pembayaran = Pembayaran::with('reservation')->get();
        return view('pembayaran.index', compact('pembayaran'));
    }

    // =======================
    // FORM CREATE PEMBAYARAN
    // =======================
    public function create($id)
    {
        $reservation = Reservation::findOrFail($id);

        return view('pembayaran.create', compact('reservation'));
    }

    // =======================
    // SIMPAN PEMBAYARAN
    // =======================
    public function store(Request $request)
    {
        $request->validate([
            'reservation_id' => 'required',
            'jumlah' => 'required|numeric',
            'metode_pembayaran' => 'required',
        ]);

        Pembayaran::create([
            'reservation_id' => $request->reservation_id,
            'jumlah' => $request->jumlah,
            'metode_pembayaran' => $request->metode_pembayaran,
            'tanggal_pembayaran' => now(),
        ]);

        // Update status reservasi
        Reservation::where('id', $request->reservation_id)
            ->update(['status' => 'Lunas']);

        return redirect()->route('pembayaran.index')->with('success', 'Pembayaran berhasil!');
    }
}
