

<?php $__env->startSection('content'); ?>
<style>
    /* Gold Estetik Styling for the Form */

    /* Container untuk header dan form */
    .container {
        padding-top: 20px;
    }
    
    /* Judul utama (Emas Tua) */
    h2 {
        color: #b8860b; /* Warna Gold */
        font-weight: 700;
        border-bottom: 2px solid #e0c896; /* Garis bawah emas lembut */
        padding-bottom: 5px;
        margin-bottom: 15px;
    }

    /* Card Form (Latar putih dengan batas emas) */
    .card {
        border-radius: 15px;
        background: white;
        /* Bayangan emas lembut */
        box-shadow: 0 4px 15px rgba(184, 134, 11, 0.15);
        border: 1px solid #e0c896; /* Garis tepi emas lembut */
    }

    /* Label Input (Cokelat Emas Tua) */
    label {
        font-weight: 600;
        color: #8b6b3e; /* Cokelat Emas Tua */
        margin-top: 8px;
        margin-bottom: 4px;
    }

    /* Input Field (Gaya yang bersih) */
    .form-control {
        border-radius: 8px;
        border: 1px solid #ccc;
        transition: border-color 0.3s;
    }

    /* Fokus pada Input (Warna Emas saat diklik) */
    .form-control:focus {
        border-color: #b8860b; /* Warna Gold saat fokus */
        box-shadow: 0 0 0 0.25rem rgba(184, 134, 11, 0.25); /* Glow emas */
    }

    /* Tombol Simpan (Gold) */
    .btn-pink {
        /* Diubah namanya menjadi btn-gold di CSS untuk konsistensi */
        background-color: #b8860b; /* Warna Gold */
        border-color: #b8860b;
        color: white;
        border-radius: 10px;
        font-weight: 600;
        transition: background-color 0.3s;
    }

    .btn-pink:hover {
        background-color: #daa520; /* Warna Goldenrod (Emas lebih terang) */
        border-color: #daa520;
        color: white;
    }
</style>

<div class="container">
    <h2>Tambah Pengguna</h2>

    <form action="<?php echo e(route('pengguna.store')); ?>" method="POST" class="card p-4 mt-3">
        <?php echo csrf_field(); ?>

        <label for="nama">Nama Pengguna (name)</label>
        <input type="text" name="nama" id="nama" class="form-control mb-2" required>

        <label for="email">Email</label>
        <input type="email" name="email" id="email" class="form-control mb-2" required>

        <label for="password">Password</label>
        <input type="password" name="password" id="password" class="form-control mb-2" required>

        <label for="alamat">Alamat</label>
        <input type="text" name="alamat" id="alamat" class="form-control mb-2">

        <label for="nomor_handphone">Nomor Telepon (nomor_handphone)</label>
        <input type="text" name="nomor_handphone" id="nomor_handphone" class="form-control mb-2">

        <button type="submit" class="btn btn-pink mt-3">Simpan Data Pengguna</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Hotel\projecthotel\resources\views/pengguna/create.blade.php ENDPATH**/ ?>