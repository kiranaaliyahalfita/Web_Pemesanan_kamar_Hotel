

<?php $__env->startSection('content'); ?>
<h2 style="margin:20px;">Data Pembayaran</h2>

<a href="<?php echo e(route('pembayaran.create')); ?>" class="btn btn-success" style="margin-left:20px;">Tambah Pembayaran</a>

<table class="table table-bordered" style="margin:20px; background:white;">
    <thead>
        <tr>
            <th>Nama</th>
            <th>Jumlah</th>
            <th>Metode</th>
            <th>Tanggal</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($p->reservation->nama_pengguna); ?></td>
            <td>Rp <?php echo e(number_format($p->jumlah_pembayaran,0,',','.')); ?></td>
            <td><?php echo e($p->metode_pembayaran); ?></td>
            <td><?php echo e($p->tanggal_pembayaran); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Hotel\projecthotel\resources\views/pembayaran/index.blade.php ENDPATH**/ ?>