

<?php $__env->startSection('content'); ?>
<div class="container mt-4">

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Email</th>
                <th>No. HP</th>
                <th>Alamat</th>
                <th width="150px">Aksi</th>
            </tr>
        </thead>

        <tbody>
            <?php $no = 1; ?>
            
            <?php $__currentLoopData = $penggunas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($item->nama); ?></td>
                <td><?php echo e($item->email); ?></td>
                <td><?php echo e($item->nomor_handphone); ?></td>
                <td><?php echo e($item->alamat); ?></td>
                
                <td>
                    <a href="<?php echo e(route('pengguna.edit', $item->id)); ?>" class="btn btn-warning btn-sm">Edit</a>

                    <form action="<?php echo e(route('pengguna.destroy', $item->id)); ?>"
                          method="POST" style="display:inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <button type="submit" class="btn btn-danger btn-sm"
                                onclick="return confirm('Hapus data ini?')">
                            Delete
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Hotel\projecthotel\resources\views/pengguna/index.blade.php ENDPATH**/ ?>