<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Hotel</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        /* Gold Estetik Theme */
        
        /* Latar belakang krem hangat */
        body {
            background-color: #fcf8e3; /* Krem lembut (Off-White/Ivory) */
            font-family: "Poppins", sans-serif;
        }

        /* Navbar dengan warna emas lembut */
        .navbar {
            background-color: #e0c896 !important; /* Emas lembut */
            box-shadow: 0 2px 8px rgba(184, 134, 11, 0.3); /* Bayangan emas */
            border-bottom: 3px solid #b8860b; /* Garis bawah emas tua */
        }

        /* Teks brand di navbar (Emas tua/Cokelat) */
        .navbar-brand {
            font-weight: bold;
            color: #8b6b3e !important; /* Cokelat Emas Tua */
            font-size: 24px;
        }

        /* Card Menu (Putih bersih dengan sentuhan emas) */
        .menu-card {
            border-radius: 18px;
            background: white;
            padding: 25px;
            /* Bayangan emas elegan */
            box-shadow: 0 4px 15px rgba(184, 134, 11, 0.15);
            transition: 0.3s;
            border: 1px solid #e0c896; /* Garis tepi emas lembut */
        }

        .menu-card:hover {
            transform: translateY(-5px);
            /* Bayangan yang lebih kuat saat di-hover */
            box-shadow: 0 8px 20px rgba(184, 134, 11, 0.3);
        }

        /* Judul Selamat Datang (Warna emas tua) */
        h2.welcome {
            font-size: 32px;
            font-weight: 700;
            color: #b8860b; /* Warna Gold */
            margin-bottom: 10px;
        }
        
        /* Judul di dalam card (Cokelat Emas) */
        .menu-card h4 {
            color: #8b6b3e; /* Cokelat Emas Tua */
            font-weight: 600;
        }
        
        /* Teks teredam (muted) */
        .text-muted {
            color: #8b6b3e !important; /* Diubah agar lebih gelap dan terbaca */
        }

        /* Tombol Utama (Warna Gold) */
        .btn-main {
            background-color: #b8860b; /* Warna Gold */
            border-color: #b8860b;
            color: white;
            border-radius: 12px;
            font-weight: 600;
        }

        .btn-main:hover {
            background-color: #daa520; /* Warna Goldenrod (Emas lebih terang) */
            border-color: #daa520;
            color: white;
        }
        
        /* Tombol Logout (Cokelat/Merah Tua) */
        .btn-danger {
            background-color: #a52a2a; /* Brown/Merah Tua */
            border-color: #a52a2a;
        }

        .btn-danger:hover {
            background-color: #800000; /* Maroon */
            border-color: #800000;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-light">
        <div class="container">
            <a class="navbar-brand" href="#"> Stego Hotel Dashboard</a>

            <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button class="btn btn-danger">Logout</button>
            </form>
        </div>
    </nav>

    <div class="container mt-5 text-center">

        <h2 class="welcome">Selamat Datang, <?php echo e(Auth::user()->name); ?> </h2>
        <p class="text-muted mb-4">Kelola data hotel Anda melalui menu di bawah ini.</p>

        <div class="row justify-content-center">

            <div class="col-md-4 mb-3">
                <div class="menu-card">
                    <h4>Kelola Pengguna</h4>
                    <p class="text-muted">Data pemesan atau tamu hotel.</p>
                    <a href="<?php echo e(route('pengguna.index')); ?>" class="btn btn-main w-100">Lihat Data</a>
                </div>
            </div>

            <div class="col-md-4 mb-3">
                <div class="menu-card">
                    <h4 class="text-center">Kelola Reservasi</h4>
                    <p class="text-muted">Daftar kamar dan pemesanan.</p>
                    <a href="<?php echo e(route('reservation.index')); ?>" class="btn btn-main w-100">Lihat Reservasi</a>
                </div>
            </div>

            <div class="col-md-4 mb-3">
                <div class="menu-card">
                    <h4 class="text-center">Kelola Pembayaran</h4>
                    <p class="text-muted">Data pembayaran dan transaksi.</p>
                    <a href="<?php echo e(route('pembayaran.index')); ?>" class="btn btn-main w-100">Lihat Pembayaran</a>
                </div>
            </div>

        </div>

    </div>

</body>
</html><?php /**PATH C:\Hotel\projecthotel\resources\views/home.blade.php ENDPATH**/ ?>