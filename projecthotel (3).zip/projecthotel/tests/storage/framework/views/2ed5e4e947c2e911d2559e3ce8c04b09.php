

<?php $__env->startSection('content'); ?>
<div class="container">

    <h3>Tambah Reservasi</h3>

    <form action="<?php echo e(route('reservation.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <label>Nama Pengguna</label>
        <input type="text" name="nama_pengguna" class="form-control" required>

        <label>Tipe Kamar</label>
        <select name="tipe_kamar" id="tipe_kamar" class="form-control" required>
            <option value="">-- Pilih Tipe Kamar --</option>
            <option value="VVIP">VVIP</option>
            <option value="VIP">VIP</option>
            <option value="CLASIC">CLASIC</option>
        </select>

        <label>Tanggal Check In</label>
        <input type="date" name="tanggal_check_in" class="form-control" required>

        <label>Tanggal Check Out</label>
        <input type="date" name="tanggal_check_out" class="form-control" required>

        <label>Status</label>
        <select name="status" class="form-control" required>
            <option value="Pending">Pending</option>
            <option value="Sukses">Sukses</option>
        </select>

        <label>Total Harga</label>
        <input type="text" id="total_harga" name="total_harga" class="form-control" readonly>

        <br>
        <button class="btn btn-success">Simpan</button>
    </form>
</div>

<script>
    document.getElementById("tipe_kamar").addEventListener("change", function () {
        let tipe = this.value;
        let harga = 0;

        if (tipe === "VVIP") harga = 500000;
        if (tipe === "VIP") harga = 300000;
        if (tipe === "CLASIC") harga = 150000;

        document.getElementById("total_harga").value = harga;
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Hotel\projecthotel\resources\views/reservation/create.blade.php ENDPATH**/ ?>