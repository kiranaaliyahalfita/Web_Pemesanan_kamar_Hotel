

<?php $__env->startSection('content'); ?>
<div class="container">

    <h3 class="mb-3">Daftar Reservasi</h3>

    <a href="<?php echo e(route('reservation.create')); ?>" class="btn btn-primary mb-3">Tambah Reservasi</a>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Nama Pengguna</th>
                <th>Tipe Kamar</th>
                <th>Check In</th>
                <th>Check Out</th>
                <th>Tanggal Booking</th>
                <th>Status</th>
                <th>Total Harga</th>
                <th width="160px">Aksi</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->nama_pengguna); ?></td>
                <td><?php echo e($item->tipe_kamar); ?></td>
                <td><?php echo e($item->tanggal_check_in); ?></td>
                <td><?php echo e($item->tanggal_check_out); ?></td>
                <td><?php echo e($item->tanggal_booking); ?></td>
                <td><?php echo e($item->status); ?></td>

                <td>Rp <?php echo e(number_format($item->total_harga, 0, ',', '.')); ?></td>

                <td>
                    <!-- PERBAIKAN FINAL: WAJIB MENGIRIMKAN ID -->
                    <a href="<?php echo e(route('reservation.edit', $item->id)); ?>" class="btn btn-warning btn-sm">
                        Edit
                    </a>

                    <form action="<?php echo e(route('reservation.destroy', $item->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger btn-sm" onclick="return confirm('Hapus data?')">
                            Hapus
                        </button>
                    </form>
                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Hotel\projecthotel\resources\views/reservation/index.blade.php ENDPATH**/ ?>