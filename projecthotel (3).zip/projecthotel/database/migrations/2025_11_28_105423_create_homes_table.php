<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateHomesTable extends Migration
{
    public function up()
    {
        Schema::create('homes', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('subtitle')->nullable();
            $table->text('description')->nullable();
            $table->string('banner_image')->nullable();
            $table->boolean('status')->default(1); // aktif / nonaktif
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('homes');
    }
}
