<?php

use Illuminate\Support\Facades\Broadcast;

/*
|--------------------------------------------------------------------------
| Broadcast Channels
|--------------------------------------------------------------------------
|
| Tempat kamu mendaftarkan channel yang dapat diakses user.
|
*/

// Private channel untuk chat
Broadcast::channel('chat.{id}', function ($user, $id) {
    // izinkan user mengakses channel jika sudah login
    return $user !== null;
});

// Private default Laravel
Broadcast::channel('App.Models.User.{id}', function ($user, $id) {
    return (int) $user->id === (int) $id;
});
